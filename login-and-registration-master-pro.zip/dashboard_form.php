<div class="col-lg-12 breadcrumb custom ">
	<div class="col-md-5">
				
		
    <h3 class="page-header">
       Login and Registration Master Pro <small> v1.0</small>
    </h3> 
    </div>	
    <div class="col-sm-3">
	    <div class="panel panel-primary">
	        <div class="panel-heading">
	            <h3 class="panel-title">Login Page Shortcode</h3>
	        </div>
	        <div class="panel-body">
	           <textarea name="lmp_login_shortcode" class="textarea_custom form-control">do_shortcode('[lrmp_login_form]')
	           </textarea>
	        </div>
	    </div>	    
	</div>
	<div class="col-sm-3">
	    <div class="panel panel-primary">
	        <div class="panel-heading">
	            <h3 class="panel-title">Registration Page Shortcode</h3>
	        </div>
	        <div class="panel-body">
	             <textarea name="lmp_registration_shortcode" class="textarea_custom form-control">do_shortcode('[lrmp_registration_form]')
	             </textarea>
	        </div>
	    </div>	    
	</div>   
</div>
<!-- 
<div class="col-lg-12">
    <div class="alert alert-info alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        Copy the bellow <strong>Shotrcodes</strong> And paste it whereever you want !
    </div>
</div> -->


